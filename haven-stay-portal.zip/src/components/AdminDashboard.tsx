import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, Lock, Eye, EyeOff, ShieldCheck, Calendar, DollarSign, Trash2, 
  CheckCircle2, UserPlus, RefreshCw, LogOut, FileText, Filter, 
  Search, Edit3, ChevronRight, Settings, Sliders, TrendingUp, 
  Activity, ArrowLeftRight, Check, Plus, AlertCircle, FileSpreadsheet
} from 'lucide-react';
import { Booking, Room } from '../types';
import { ROOMS } from '../data/havenData';

interface AdminDashboardProps {
  isOpen: boolean;
  onClose: () => void;
  bookings: Booking[];
  onBookingDeleted: (bookingId: string) => void;
  onBookingUpdated: (updatedBooking: Booking) => void;
  onAddSampleBooking: (newBooking: Booking) => void;
}

type ActiveTab = 'overview' | 'ledger' | 'scheduler' | 'create-booking';

export default function AdminDashboard({
  isOpen,
  onClose,
  bookings,
  onBookingDeleted,
  onBookingUpdated,
  onAddSampleBooking
}: AdminDashboardProps) {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [loginLoading, setLoginLoading] = useState(false);

  // Active workspace tab
  const [activeTab, setActiveTab] = useState<ActiveTab>('overview');

  // Filter & Search states
  const [searchTerm, setSearchTerm] = useState('');
  const [roomFilter, setRoomFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sortBy, setSortBy] = useState<'date-desc' | 'date-asc' | 'amount-desc' | 'name-asc'>('date-desc');

  // Action states
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);
  const [actionError, setActionError] = useState('');
  const [csvSuccess, setCsvSuccess] = useState(false);
  const [systemLogs, setSystemLogs] = useState<string[]>([
    "Sanctuary ledger initialized.",
    "System stashed secure keys on port 3000."
  ]);

  // Inline editing state
  const [editingBooking, setEditingBooking] = useState<Booking | null>(null);
  const [editName, setEditName] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editCheckIn, setEditCheckIn] = useState('');
  const [editCheckOut, setEditCheckOut] = useState('');
  const [editAmount, setEditAmount] = useState<number>(0);
  const [editStatus, setEditStatus] = useState<'confirmed' | 'pending' | 'checked-in' | 'cancelled'>('confirmed');

  // Direct manual booking state
  const [newRoomId, setNewRoomId] = useState('hearth-suite');
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newCheckIn, setNewCheckIn] = useState('');
  const [newCheckOut, setNewCheckOut] = useState('');
  const [newAmount, setNewAmount] = useState<string>('');

  // Reset states when closed
  useEffect(() => {
    if (!isOpen) {
      setLoginError('');
      setActionError('');
    }
  }, [isOpen]);

  const pushLog = (message: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setSystemLogs(prev => [`[${timestamp}] ${message}`, ...prev.slice(0, 8)]);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      setLoginError('Credentials must be entered to review the Ledger.');
      return;
    }

    setLoginLoading(true);
    setLoginError('');

    try {
      const response = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });

      const data = await response.json();
      if (data.success) {
        setIsLoggedIn(true);
        setLoginError('');
        pushLog("Keeper authenticated successfully.");
      } else {
        setLoginError(data.error || 'The secret passage is blocked.');
      }
    } catch (err) {
      setLoginError('Could not connect to the authentication hearth.');
    } finally {
      setLoginLoading(false);
    }
  };

  const confirmLogout = () => {
    setIsLoggedIn(false);
    setUsername('');
    setPassword('');
    setShowLogoutConfirm(false);
    pushLog("Keeper logged out of dashboard.");
  };

  const handleLogout = () => {
    setShowLogoutConfirm(true);
  };

  // Status cycling: confirmed -> pending -> checked-in -> cancelled -> confirmed
  const handleCycleStatus = async (booking: Booking) => {
    setActionLoadingId(booking.id);
    setActionError('');
    let nextStatus: Booking['status'] = 'confirmed';
    if (booking.status === 'confirmed') nextStatus = 'pending';
    else if (booking.status === 'pending') nextStatus = 'checked-in';
    else if (booking.status === 'checked-in') nextStatus = 'cancelled';
    else if (booking.status === 'cancelled') nextStatus = 'confirmed';

    try {
      const response = await fetch(`/api/bookings/${booking.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: nextStatus })
      });

      const data = await response.json();
      if (data.success) {
        onBookingUpdated(data.data);
        pushLog(`Booking #${booking.id.replace('booking-', '')} status updated to ${nextStatus}.`);
      } else {
        setActionError('Failed to update reservation status.');
      }
    } catch (err) {
      setActionError('Error communicating with the booking server.');
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleDeleteBooking = async (id: string) => {
    if (!window.confirm('Are you sure you want to completely release this reservation from the Kashmiri records?')) {
      return;
    }

    setActionLoadingId(id);
    setActionError('');

    try {
      const response = await fetch(`/api/bookings/${id}`, {
        method: 'DELETE'
      });

      const data = await response.json();
      if (data.success) {
        onBookingDeleted(id);
        pushLog(`Reservation #${id.replace('booking-', '')} removed from ledger.`);
        if (editingBooking?.id === id) {
          setEditingBooking(null);
        }
      } else {
        setActionError('Failed to remove reservation from ledger.');
      }
    } catch (err) {
      setActionError('Could not contact server to delete booking.');
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleCreateMockBooking = async () => {
    setActionLoadingId('mock-creation');
    setActionError('');

    const randomGuests = [
      { name: "Julian Alcott", email: "julian@alcott-design.co" },
      { name: "Amara Vance", email: "amara@vance-photo.org" },
      { name: "Vikram Sen", email: "vikram.sen@valley-tea.in" },
      { name: "Priya Sharma", email: "priya.sharma@himalayas.com" },
      { name: "Kabir Dar", email: "kabir.dar@srinagar-arts.co" }
    ];
    const guest = randomGuests[Math.floor(Math.random() * randomGuests.length)]!;
    const rooms = ['hearth-suite', 'valley-view-cabin'];
    const randomRoomId = rooms[Math.floor(Math.random() * rooms.length)]!;
    const checkInDate = new Date();
    checkInDate.setDate(checkInDate.getDate() + Math.floor(Math.random() * 30) + 2);
    const checkOutDate = new Date(checkInDate);
    checkOutDate.setDate(checkOutDate.getDate() + Math.floor(Math.random() * 5) + 2);

    const checkInStr = checkInDate.toISOString().split('T')[0];
    const checkOutStr = checkOutDate.toISOString().split('T')[0];
    const duration = Math.ceil((checkOutDate.getTime() - checkInDate.getTime()) / (1000 * 3600 * 24));
    
    const rate = randomRoomId === 'hearth-suite' ? 24500 : 28000;
    const finalAmount = rate * duration;

    try {
      const response = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          roomId: randomRoomId,
          guestName: guest.name,
          guestEmail: guest.email,
          checkIn: checkInStr,
          checkOut: checkOutStr,
          amount: finalAmount
        })
      });

      const data = await response.json();
      if (data.success) {
        onAddSampleBooking(data.data);
        pushLog(`Simulated stay logged for ${guest.name} (${data.data.roomTitle}).`);
      } else {
        setActionError('Could not write simulated guest.');
      }
    } catch (err) {
      setActionError('Error while stoking mock ledger data.');
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleManualBookingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newEmail || !newCheckIn || !newCheckOut) {
      setActionError('Please complete all form fields to book manually.');
      return;
    }

    setActionLoadingId('manual-submit');
    setActionError('');

    const targetRoom = ROOMS.find(r => r.id === newRoomId) || ROOMS[0]!;
    const days = Math.max(1, Math.ceil((new Date(newCheckOut).getTime() - new Date(newCheckIn).getTime()) / (1000 * 3600 * 24)));
    const autoAmount = targetRoom.pricePerNight * days;
    const finalAmount = newAmount ? parseFloat(newAmount) : autoAmount;

    try {
      const response = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          roomId: newRoomId,
          guestName: newName,
          guestEmail: newEmail,
          checkIn: newCheckIn,
          checkOut: newCheckOut,
          amount: finalAmount
        })
      });

      const data = await response.json();
      if (data.success) {
        onAddSampleBooking(data.data);
        pushLog(`Manual reservation logged for ${newName}.`);
        // Reset form
        setNewName('');
        setNewEmail('');
        setNewCheckIn('');
        setNewCheckOut('');
        setNewAmount('');
        setActiveTab('ledger');
      } else {
        setActionError(data.error || 'Failed to record manual reservation.');
      }
    } catch (err) {
      setActionError('Error communicating with ledger registry.');
    } finally {
      setActionLoadingId(null);
    }
  };

  const startEditing = (booking: Booking) => {
    setEditingBooking(booking);
    setEditName(booking.guestName);
    setEditEmail(booking.guestEmail);
    setEditCheckIn(booking.checkIn);
    setEditCheckOut(booking.checkOut);
    setEditAmount(booking.amount);
    setEditStatus(booking.status);
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBooking) return;

    setActionLoadingId(editingBooking.id);
    setActionError('');

    try {
      // First update status if changed
      const resStatus = await fetch(`/api/bookings/${editingBooking.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: editStatus })
      });

      const dataStatus = await resStatus.json();
      if (dataStatus.success) {
        // Update local object representation with other fields
        const updatedObj: Booking = {
          ...dataStatus.data,
          guestName: editName,
          guestEmail: editEmail,
          checkIn: editCheckIn,
          checkOut: editCheckOut,
          amount: editAmount
        };
        onBookingUpdated(updatedObj);
        pushLog(`Updated reservation parameters for ${editName}.`);
        setEditingBooking(null);
      } else {
        setActionError('Failed to modify reservation records.');
      }
    } catch (err) {
      setActionError('Error saving changes to server.');
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleDownloadLedger = () => {
    setCsvSuccess(true);
    setTimeout(() => setCsvSuccess(false), 3000);

    // Create virtual CSV file content
    const csvHeader = "Booking ID,Room ID,Room Title,Guest Name,Guest Email,Check-In,Check-Out,Amount (INR),Status,Booked At\n";
    const csvRows = bookings.map(b => 
      `"${b.id}","${b.roomId}","${b.roomTitle.replace(/"/g, '""')}","${b.guestName.replace(/"/g, '""')}","${b.guestEmail.replace(/"/g, '""')}","${b.checkIn}","${b.checkOut}",${b.amount},"${b.status}","${b.bookedAt}"`
    ).join("\n");
    const blob = new Blob([csvHeader + csvRows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `haven_retreat_ledger_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    pushLog("Stashed and downloaded full ledger backup as CSV.");
  };

  // Stats Calculations
  const activeBookings = bookings.filter(b => b.status !== 'cancelled');
  const totalBookingsCount = bookings.length;
  const activeStaysCount = bookings.filter(b => b.status === 'checked-in').length;
  const pendingStaysCount = bookings.filter(b => b.status === 'pending').length;
  const confirmedStaysCount = bookings.filter(b => b.status === 'confirmed').length;

  const totalRevenue = activeBookings.reduce((sum, b) => sum + b.amount, 0);
  const averageValue = activeBookings.length > 0 ? Math.round(totalRevenue / activeBookings.length) : 0;

  // Occupancy rate calculation (simple ratio based on sample stay days over a typical month)
  const roomOccupancy = Math.min(100, Math.round((activeBookings.length * 3.5 / 60) * 100));

  // Filter & Search Logic
  const filteredBookings = bookings.filter(b => {
    const matchesSearch = b.guestName.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          b.guestEmail.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          b.id.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesRoom = roomFilter === 'all' || b.roomId === roomFilter;
    const matchesStatus = statusFilter === 'all' || b.status === statusFilter;

    return matchesSearch && matchesRoom && matchesStatus;
  });

  // Sort Logic
  const sortedBookings = [...filteredBookings].sort((a, b) => {
    if (sortBy === 'date-desc') return new Date(b.checkIn).getTime() - new Date(a.checkIn).getTime();
    if (sortBy === 'date-asc') return new Date(a.checkIn).getTime() - new Date(b.checkIn).getTime();
    if (sortBy === 'amount-desc') return b.amount - a.amount;
    if (sortBy === 'name-asc') return a.guestName.localeCompare(b.guestName);
    return 0;
  });

  // Simple Timeline Scheduler data mapping
  // Get next 14 days to display
  const getTimelineDays = () => {
    const days = [];
    const now = new Date();
    for (let i = 0; i < 14; i++) {
      const d = new Date(now);
      d.setDate(now.getDate() + i);
      days.push(d);
    }
    return days;
  };
  const timelineDays = getTimelineDays();

  // Helper to check if a cabin is booked on a specific day
  const getBookingForDay = (roomId: string, date: Date) => {
    const dateStr = date.toISOString().split('T')[0];
    return bookings.find(b => {
      if (b.roomId !== roomId || b.status === 'cancelled') return false;
      return dateStr >= b.checkIn && dateStr <= b.checkOut;
    });
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 bg-zinc-950 flex flex-col md:flex-row overflow-hidden font-sans text-zinc-300">
        
        {!isLoggedIn ? (
          /* LOCK SCREEN PANEL WITH MAJESTIC WOOD TEXTURE */
          <div className="flex-grow flex items-center justify-center p-6 relative bg-zinc-950">
            {/* Ambient Background Glow */}
            <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
            
            <motion.div
              initial={{ opacity: 0, scale: 0.97, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.97, y: 10 }}
              className="relative bg-zinc-900 border border-zinc-800/80 rounded p-8 md:p-10 w-full max-w-md shadow-2xl z-10 space-y-6"
            >
              {/* Back button */}
              <button
                onClick={onClose}
                className="absolute top-4 left-4 p-2 text-zinc-500 hover:text-white rounded hover:bg-zinc-800/40 transition-colors cursor-pointer flex items-center gap-1 text-xs font-mono uppercase"
              >
                <X className="w-3.5 h-3.5" />
                <span>Guest Site</span>
              </button>

              <div className="text-center space-y-2 pt-4">
                <div className="w-12 h-12 bg-amber-500/10 border border-amber-500/20 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Lock className="w-5 h-5 text-amber-500" />
                </div>
                <span className="font-mono text-[9px] tracking-[0.35em] text-amber-500 uppercase font-semibold block">
                  STAFF PORTAL LOCKSCREEN
                </span>
                <h3 className="font-serif text-3xl font-bold text-zinc-100">
                  Haven Registrar
                </h3>
                <p className="text-zinc-500 text-xs font-light">
                  Input authorization codes to view guest timelines and treasury.
                </p>
              </div>

              {loginError && (
                <div className="p-3.5 bg-red-950/40 border border-red-500/20 text-red-400 text-xs rounded text-center font-light leading-relaxed">
                  {loginError}
                </div>
              )}

              <form onSubmit={handleLogin} className="space-y-4">
                {/* Username */}
                <div className="space-y-1.5">
                  <label className="font-mono text-[8px] text-zinc-500 tracking-widest uppercase block">
                    Staff Username
                  </label>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Enter 'admin'"
                    className="w-full px-4 py-3 bg-zinc-950 border border-zinc-850 focus:border-amber-500/50 rounded text-sm focus:outline-none text-zinc-200 font-light"
                    required
                  />
                </div>

                {/* Password */}
                <div className="space-y-1.5">
                  <label className="font-mono text-[8px] text-zinc-500 tracking-widest uppercase block">
                    Passcode Key
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter 'haven2026'"
                      className="w-full px-4 py-3 bg-zinc-950 border border-zinc-850 focus:border-amber-500/50 rounded text-sm focus:outline-none text-zinc-200 font-light pr-10"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-zinc-600 hover:text-zinc-400 cursor-pointer"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Credentials reminder */}
                <div className="p-3.5 bg-zinc-950 rounded border border-zinc-900 text-[11px] text-zinc-500 leading-relaxed font-light">
                  <span className="font-semibold text-amber-500/70 block mb-0.5">🔑 Registrar Credentials:</span>
                  Username: <code className="text-zinc-300 font-mono">admin</code><br />
                  Password: <code className="text-zinc-300 font-mono">haven2026</code>
                </div>

                <button
                  type="submit"
                  disabled={loginLoading}
                  className="w-full py-3.5 bg-amber-600 hover:bg-amber-500 disabled:bg-zinc-800 text-zinc-950 font-bold rounded tracking-widest uppercase text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg"
                >
                  {loginLoading ? 'Stoking Authentication Key...' : 'Unlock Sanctum Ledger'}
                </button>
              </form>
            </motion.div>
          </div>
        ) : (
          /* ACTIVE FULL-SCREEN WORKSPACE */
          <div className="flex flex-col md:flex-row w-full h-screen overflow-hidden">
            
            {/* LEFT BAR: MAIN DASHBOARD NAVIGATION */}
            <div className="w-full md:w-64 bg-zinc-900 border-r border-zinc-850 flex flex-col justify-between p-5 shrink-0 z-20">
              <div className="space-y-6">
                {/* Brand Identifier */}
                <div className="flex items-center gap-3 pb-4 border-b border-zinc-850">
                  <div className="w-8 h-8 bg-amber-500/10 border border-amber-500/20 rounded flex items-center justify-center">
                    <ShieldCheck className="w-4 h-4 text-amber-500" />
                  </div>
                  <div>
                    <h3 className="font-serif text-lg font-bold text-zinc-100 leading-none">Haven Registrar</h3>
                    <span className="font-mono text-[8px] tracking-[0.2em] text-amber-500 uppercase block mt-1">
                      VALLEY LEDGER ACTIVE
                    </span>
                  </div>
                </div>

                {/* Navigation Links */}
                <nav className="space-y-1.5">
                  <button
                    onClick={() => setActiveTab('overview')}
                    className={`w-full text-left px-3.5 py-2.5 rounded font-mono text-xs uppercase tracking-wider flex items-center gap-2.5 transition-colors cursor-pointer ${
                      activeTab === 'overview'
                        ? 'bg-amber-600 text-zinc-950 font-bold'
                        : 'text-zinc-400 hover:text-white hover:bg-zinc-850'
                    }`}
                  >
                    <TrendingUp className="w-4 h-4" />
                    <span>Overview & Analytics</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('ledger')}
                    className={`w-full text-left px-3.5 py-2.5 rounded font-mono text-xs uppercase tracking-wider flex items-center gap-2.5 transition-colors cursor-pointer ${
                      activeTab === 'ledger'
                        ? 'bg-amber-600 text-zinc-950 font-bold'
                        : 'text-zinc-400 hover:text-white hover:bg-zinc-850'
                    }`}
                  >
                    <Sliders className="w-4 h-4" />
                    <span>Guest Registry ({bookings.length})</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('scheduler')}
                    className={`w-full text-left px-3.5 py-2.5 rounded font-mono text-xs uppercase tracking-wider flex items-center gap-2.5 transition-colors cursor-pointer ${
                      activeTab === 'scheduler'
                        ? 'bg-amber-600 text-zinc-950 font-bold'
                        : 'text-zinc-400 hover:text-white hover:bg-zinc-850'
                    }`}
                  >
                    <Calendar className="w-4 h-4" />
                    <span>Scheduler Timeline</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('create-booking')}
                    className={`w-full text-left px-3.5 py-2.5 rounded font-mono text-xs uppercase tracking-wider flex items-center gap-2.5 transition-colors cursor-pointer ${
                      activeTab === 'create-booking'
                        ? 'bg-amber-600 text-zinc-950 font-bold'
                        : 'text-zinc-400 hover:text-white hover:bg-zinc-850'
                    }`}
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add Manual Booking</span>
                  </button>
                </nav>
              </div>

              {/* Sidebar bottom activities & actions */}
              <div className="space-y-4 pt-4 border-t border-zinc-850">
                {/* Console System Logs */}
                <div className="bg-zinc-950 p-3 rounded border border-zinc-850 text-[10px] font-mono text-zinc-500 h-28 overflow-y-auto space-y-1.5 scrollbar-thin">
                  <span className="text-zinc-600 block uppercase tracking-widest text-[8px] font-bold pb-1 border-b border-zinc-900">
                    Live Session Log
                  </span>
                  {systemLogs.map((log, index) => (
                    <div key={index} className="leading-tight break-all font-light">
                      {log}
                    </div>
                  ))}
                </div>

                <div className="flex flex-col gap-2">
                  <button
                    onClick={onClose}
                    className="w-full py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded text-xs font-mono uppercase tracking-widest text-center cursor-pointer transition-colors"
                  >
                    Return to Portal
                  </button>

                  <button
                    onClick={handleLogout}
                    className="w-full py-2 bg-red-950/40 hover:bg-red-900/30 border border-red-900/20 text-red-400 hover:text-red-300 rounded text-xs font-mono uppercase tracking-widest text-center cursor-pointer transition-colors"
                  >
                    Logout staff
                  </button>
                </div>
              </div>

            </div>

            {/* RIGHT WORKSPACE: DYNAMIC CONTENT TABS */}
            <div className="flex-grow flex flex-col overflow-hidden bg-zinc-950">
              
              {/* Header Ribbon bar */}
              <header className="px-6 md:px-8 py-5 border-b border-zinc-850 bg-zinc-900 flex flex-col sm:flex-row justify-between sm:items-center gap-4 shrink-0">
                <div>
                  <span className="font-mono text-[9px] tracking-widest text-zinc-500 uppercase block font-semibold">
                    KASHMIR MOUNTAIN SYSTEM / SANCTUARY ADMINISTRATION
                  </span>
                  <h2 className="font-serif text-2xl md:text-3xl font-bold text-zinc-100 mt-0.5">
                    {activeTab === 'overview' && 'Hearth Analytics Overview'}
                    {activeTab === 'ledger' && 'Guest Booking Ledger'}
                    {activeTab === 'scheduler' && 'Hearth Stay Grid Scheduler'}
                    {activeTab === 'create-booking' && 'Manual Check-in Setup'}
                  </h2>
                </div>

                {/* Direct quick action stashing */}
                <div className="flex items-center gap-2.5">
                  <button
                    onClick={handleCreateMockBooking}
                    disabled={actionLoadingId === 'mock-creation'}
                    className="flex items-center gap-1.5 px-3 py-1.5 border border-zinc-800 hover:border-zinc-750 bg-zinc-950 hover:bg-zinc-900 text-xs text-zinc-400 hover:text-white rounded transition-colors font-mono cursor-pointer"
                    title="Generate virtual randomized stay logs to test the interface"
                  >
                    <UserPlus className="w-3.5 h-3.5 text-amber-500" />
                    <span>Simulate Guest Stay</span>
                  </button>

                  <button
                    onClick={handleDownloadLedger}
                    className="flex items-center gap-1.5 px-3 py-1.5 border border-zinc-800 hover:border-zinc-750 bg-zinc-950 hover:bg-zinc-900 text-xs text-zinc-400 hover:text-white rounded transition-colors font-mono cursor-pointer"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-500" />
                    <span>{csvSuccess ? 'CSV Saved' : 'Download Ledger CSV'}</span>
                  </button>
                </div>
              </header>

              {/* Main Content Workspace viewport */}
              <main className="flex-grow overflow-y-auto p-6 md:p-8 space-y-6">
                
                {actionError && (
                  <div className="p-4 bg-red-950/40 border border-red-500/25 text-red-400 text-xs rounded flex items-center gap-3">
                    <AlertCircle className="w-4 h-4" />
                    <span>{actionError}</span>
                  </div>
                )}

                {/* TAB 1: OVERVIEW & ANALYTICS */}
                {activeTab === 'overview' && (
                  <div className="space-y-6">
                    
                    {/* Analytics Bento Stats Cards */}
                    <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                      {/* Stat 1: Cumulative Revenue */}
                      <div className="bg-zinc-900 p-5 rounded border border-zinc-850 flex flex-col justify-between relative overflow-hidden">
                        <span className="font-mono text-[9px] text-zinc-500 uppercase tracking-widest">
                          CUMULATIVE BOOKED REVENUE
                        </span>
                        <div className="mt-2.5">
                          <h4 className="font-serif text-3xl font-bold text-amber-400">
                            ₹{totalRevenue.toLocaleString('en-IN')}
                          </h4>
                          <span className="text-[10px] text-zinc-500 block mt-1">Stoked stays revenue value</span>
                        </div>
                        <Activity className="w-10 h-10 text-zinc-800 absolute right-4 bottom-4 pointer-events-none" />
                      </div>

                      {/* Stat 2: Active Registrations */}
                      <div className="bg-zinc-900 p-5 rounded border border-zinc-850 flex flex-col justify-between relative overflow-hidden">
                        <span className="font-mono text-[9px] text-zinc-500 uppercase tracking-widest">
                          ACTIVE RESERVATIONS
                        </span>
                        <div className="mt-2.5">
                          <h4 className="font-serif text-3xl font-bold text-zinc-100">
                            {activeBookings.length}
                          </h4>
                          <span className="text-[10px] text-zinc-500 block mt-1">
                            {confirmedStaysCount} Confirmed, {pendingStaysCount} Pending
                          </span>
                        </div>
                        <Calendar className="w-10 h-10 text-zinc-800 absolute right-4 bottom-4 pointer-events-none" />
                      </div>

                      {/* Stat 3: Checked In guests */}
                      <div className="bg-zinc-900 p-5 rounded border border-zinc-850 flex flex-col justify-between relative overflow-hidden">
                        <span className="font-mono text-[9px] text-zinc-500 uppercase tracking-widest">
                          CURRENTLY CHECKED IN
                        </span>
                        <div className="mt-2.5">
                          <h4 className="font-serif text-3xl font-bold text-emerald-500">
                            {activeStaysCount}
                          </h4>
                          <span className="text-[10px] text-zinc-500 block mt-1">In-house guests warming at fireplace</span>
                        </div>
                        <CheckCircle2 className="w-10 h-10 text-zinc-800 absolute right-4 bottom-4 pointer-events-none" />
                      </div>

                      {/* Stat 4: Avg Order stay Value */}
                      <div className="bg-zinc-900 p-5 rounded border border-zinc-850 flex flex-col justify-between relative overflow-hidden">
                        <span className="font-mono text-[9px] text-zinc-500 uppercase tracking-widest">
                          AVERAGE TICKET SIZE
                        </span>
                        <div className="mt-2.5">
                          <h4 className="font-serif text-3xl font-bold text-zinc-100">
                            ₹{averageValue.toLocaleString('en-IN')}
                          </h4>
                          <span className="text-[10px] text-zinc-500 block mt-1">Per active reservation stayed</span>
                        </div>
                        <Sliders className="w-10 h-10 text-zinc-800 absolute right-4 bottom-4 pointer-events-none" />
                      </div>
                    </div>

                    {/* Rich Data Visualizations Grid (Custom SVG Analytics) */}
                    <div className="grid lg:grid-cols-12 gap-6">
                      
                      {/* Left Block: Interactive Revenue Growth Graph */}
                      <div className="lg:col-span-8 bg-zinc-900 p-6 rounded border border-zinc-850 space-y-4">
                        <div className="flex justify-between items-center pb-2 border-b border-zinc-850/40">
                          <div>
                            <h3 className="font-serif text-lg font-bold text-zinc-100">Monthly Revenue Pipeline</h3>
                            <p className="text-[11px] text-zinc-500 font-light">Interactive tracking of stashed treasury value across summer bookings</p>
                          </div>
                          <span className="text-[10px] font-mono text-amber-500 border border-amber-500/10 px-2 py-0.5 rounded bg-amber-500/5 uppercase font-medium">
                            ₹ INR Treasury
                          </span>
                        </div>

                        {/* Interactive SVG graph chart */}
                        <div className="h-64 relative flex items-end pt-6">
                          {/* Y Axis Guides */}
                          <div className="absolute inset-0 flex flex-col justify-between text-[9px] font-mono text-zinc-650 pointer-events-none pb-8 pt-4">
                            <div className="border-b border-zinc-800/50 w-full text-right pr-2">₹2,00,000</div>
                            <div className="border-b border-zinc-800/50 w-full text-right pr-2">₹1,50,000</div>
                            <div className="border-b border-zinc-800/50 w-full text-right pr-2">₹1,00,000</div>
                            <div className="border-b border-zinc-800/50 w-full text-right pr-2">₹50,000</div>
                            <div className="w-full text-right pr-2">₹0</div>
                          </div>

                          {/* Graph Columns wrapper */}
                          <div className="w-full h-full flex justify-around items-end z-10 pl-16 pb-8 relative">
                            {/* We will map dummy points styled to reflect realistic room distribution based on our bookings array */}
                            {[
                              { label: 'May Stays', val: Math.min(180000, totalRevenue * 0.3 + 45000), color: '#b45309' },
                              { label: 'June Stays', val: Math.min(220000, totalRevenue * 0.5 + 80000), color: '#d97706' },
                              { label: 'July Stays (Active)', val: totalRevenue, color: '#f59e0b' },
                              { label: 'Aug (Projected)', val: totalRevenue * 1.25 + 60000, color: '#10b981' }
                            ].map((col, idx) => {
                              const pct = Math.min(100, Math.max(12, (col.val / 220000) * 100));
                              return (
                                <div key={idx} className="flex flex-col items-center h-full justify-end w-20 group relative cursor-pointer">
                                  {/* Tooltip info */}
                                  <div className="absolute -top-6 bg-zinc-950 text-[10px] font-mono px-2 py-1 border border-zinc-800 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap text-zinc-200 z-30">
                                    ₹{Math.round(col.val).toLocaleString('en-IN')}
                                  </div>
                                  {/* Visual bar */}
                                  <div 
                                    className="w-10 rounded-t transition-all duration-1000 group-hover:brightness-110 shadow-lg shadow-black/40"
                                    style={{ 
                                      height: `${pct}%`, 
                                      backgroundColor: col.color,
                                    }}
                                  />
                                  <span className="font-mono text-[9px] text-zinc-500 mt-2.5 truncate max-w-full">
                                    {col.label}
                                  </span>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      </div>

                      {/* Right Block: Cabin Occupancy Distribution */}
                      <div className="lg:col-span-4 bg-zinc-900 p-6 rounded border border-zinc-850 space-y-4">
                        <h3 className="font-serif text-lg font-bold text-zinc-100 pb-2 border-b border-zinc-850/40">
                          Sanctuary Allocation
                        </h3>
                        
                        <div className="space-y-4">
                          {/* Cabin Item 1 */}
                          <div className="space-y-1.5">
                            <div className="flex justify-between items-center text-xs">
                              <span className="font-serif font-medium text-zinc-200">The Hearth Suite</span>
                              <span className="font-mono text-zinc-400">
                                {bookings.filter(b => b.roomId === 'hearth-suite' && b.status !== 'cancelled').length} stays
                              </span>
                            </div>
                            <div className="w-full h-2 bg-zinc-950 rounded overflow-hidden">
                              <div 
                                className="h-full bg-amber-600 rounded transition-all duration-500" 
                                style={{ 
                                  width: `${Math.min(100, (bookings.filter(b => b.roomId === 'hearth-suite' && b.status !== 'cancelled').length / Math.max(1, activeBookings.length)) * 100)}%` 
                                }}
                              />
                            </div>
                          </div>

                          {/* Cabin Item 2 */}
                          <div className="space-y-1.5">
                            <div className="flex justify-between items-center text-xs">
                              <span className="font-serif font-medium text-zinc-200">The Valley View Cabin</span>
                              <span className="font-mono text-zinc-400">
                                {bookings.filter(b => b.roomId === 'valley-view-cabin' && b.status !== 'cancelled').length} stays
                              </span>
                            </div>
                            <div className="w-full h-2 bg-zinc-950 rounded overflow-hidden">
                              <div 
                                className="h-full bg-amber-500 rounded transition-all duration-500" 
                                style={{ 
                                  width: `${Math.min(100, (bookings.filter(b => b.roomId === 'valley-view-cabin' && b.status !== 'cancelled').length / Math.max(1, activeBookings.length)) * 100)}%` 
                                }}
                              />
                            </div>
                          </div>
                        </div>

                        {/* Informational Box */}
                        <div className="p-4 bg-zinc-950 rounded border border-zinc-850/80 text-xs text-zinc-500 leading-relaxed font-light">
                          <span className="font-semibold text-amber-500 block mb-1">💡 Occupancy Signal:</span>
                          The valley mist is clearing for summer. Stays in <strong className="text-zinc-400">The Hearth Suite</strong> are currently commanding high reservation value due to cozy fireplace evenings.
                        </div>

                      </div>

                    </div>

                  </div>
                )}

                {/* TAB 2: INTERACTIVE SCHEDULER */}
                {activeTab === 'scheduler' && (
                  <div className="bg-zinc-900 p-6 rounded border border-zinc-850 space-y-6">
                    <div className="space-y-1">
                      <h3 className="font-serif text-xl font-bold text-zinc-100">Stay Planner (14-Day View)</h3>
                      <p className="text-xs text-zinc-500 font-light">Visual calendar mapping active stay allocations for both sanctuary cabins.</p>
                    </div>

                    <div className="overflow-x-auto">
                      <div className="min-w-[800px] border border-zinc-850 rounded bg-zinc-950">
                        {/* Calendar timeline days row */}
                        <div className="grid grid-cols-15 border-b border-zinc-850 font-mono text-[9px] uppercase tracking-wider text-zinc-500 bg-zinc-900/35">
                          <div className="p-3.5 border-r border-zinc-850 font-semibold">Sanctuary Cabin</div>
                          {timelineDays.map((day, idx) => (
                            <div key={idx} className="p-3.5 text-center border-r border-zinc-850/60 flex flex-col items-center">
                              <span>{day.toLocaleDateString('en-US', { weekday: 'short' })}</span>
                              <span className="text-zinc-300 font-bold mt-0.5">{day.getDate()}</span>
                            </div>
                          ))}
                        </div>

                        {/* Rooms rows */}
                        {ROOMS.map((room) => (
                          <div key={room.id} className="grid grid-cols-15 border-b border-zinc-850/50">
                            {/* Room title cell */}
                            <div className="p-4 border-r border-zinc-850 bg-zinc-900/10 flex flex-col justify-center">
                              <span className="font-serif text-xs font-semibold text-zinc-200">{room.title}</span>
                              <span className="text-[9px] font-mono text-zinc-500 mt-1 uppercase">₹{room.pricePerNight.toLocaleString('en-IN')}/N</span>
                            </div>

                            {/* Timeline day cells */}
                            {timelineDays.map((day, idx) => {
                              const match = getBookingForDay(room.id, day);
                              return (
                                <div key={idx} className="p-2 border-r border-zinc-850/60 min-h-[70px] relative flex items-center justify-center bg-zinc-950/20">
                                  {match ? (
                                    <div 
                                      className={`absolute inset-1 rounded px-2.5 py-1.5 flex flex-col justify-between overflow-hidden shadow text-[9px] font-mono leading-none border select-none ${
                                        match.status === 'checked-in'
                                          ? 'bg-emerald-950/60 border-emerald-500/30 text-emerald-300'
                                          : 'bg-amber-950/60 border-amber-500/30 text-amber-300'
                                      }`}
                                      title={`Guest: ${match.guestName} (${match.checkIn} to ${match.checkOut})`}
                                    >
                                      <span className="font-semibold truncate block">{match.guestName.split(' ')[0]}</span>
                                      <span className="text-[7px] text-zinc-500 truncate block mt-1 uppercase">{match.status}</span>
                                    </div>
                                  ) : (
                                    <span className="text-[9px] font-mono text-zinc-800 italic">-</span>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="flex items-center gap-6 text-[10px] font-mono text-zinc-500">
                      <div className="flex items-center gap-1.5">
                        <span className="w-2.5 h-2.5 rounded bg-amber-950/60 border border-amber-500/30 block" />
                        <span>Confirmed Booking</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="w-2.5 h-2.5 rounded bg-emerald-950/60 border border-emerald-500/30 block" />
                        <span>Checked In stay</span>
                      </div>
                    </div>
                  </div>
                )}

                {/* TAB 3: REGISTRY LEDGER */}
                {activeTab === 'ledger' && (
                  <div className="space-y-6">
                    
                    {/* Filters & Search Box */}
                    <div className="grid md:grid-cols-12 gap-4 bg-zinc-900 p-4 rounded border border-zinc-850">
                      
                      {/* Search */}
                      <div className="md:col-span-4 relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                        <input
                          type="text"
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          placeholder="Search guests or ID..."
                          className="w-full bg-zinc-950 border border-zinc-850 focus:border-amber-500/50 rounded pl-9 pr-4 py-2 text-xs text-zinc-350 placeholder-zinc-700 focus:outline-none"
                        />
                      </div>

                      {/* Room filter */}
                      <div className="md:col-span-3 flex items-center gap-2">
                        <span className="font-mono text-[8px] text-zinc-500 uppercase tracking-wider whitespace-nowrap">Cabin:</span>
                        <select
                          value={roomFilter}
                          onChange={(e) => setRoomFilter(e.target.value)}
                          className="w-full bg-zinc-950 border border-zinc-850 text-zinc-400 focus:text-zinc-200 text-xs rounded px-2 py-1.5 cursor-pointer focus:outline-none"
                        >
                          <option value="all">All Sanctuaries</option>
                          <option value="hearth-suite">The Hearth Suite</option>
                          <option value="valley-view-cabin">The Valley View Cabin</option>
                        </select>
                      </div>

                      {/* Status filter */}
                      <div className="md:col-span-3 flex items-center gap-2">
                        <span className="font-mono text-[8px] text-zinc-500 uppercase tracking-wider whitespace-nowrap">State:</span>
                        <select
                          value={statusFilter}
                          onChange={(e) => setStatusFilter(e.target.value)}
                          className="w-full bg-zinc-950 border border-zinc-850 text-zinc-400 focus:text-zinc-200 text-xs rounded px-2 py-1.5 cursor-pointer focus:outline-none"
                        >
                          <option value="all">All States</option>
                          <option value="confirmed">Confirmed</option>
                          <option value="pending">Pending</option>
                          <option value="checked-in">Checked In</option>
                          <option value="cancelled">Cancelled</option>
                        </select>
                      </div>

                      {/* Sorting filter */}
                      <div className="md:col-span-2 flex items-center gap-2">
                        <select
                          value={sortBy}
                          onChange={(e: any) => setSortBy(e.target.value)}
                          className="w-full bg-zinc-950 border border-zinc-850 text-zinc-400 focus:text-zinc-200 text-xs rounded px-2 py-1.5 cursor-pointer focus:outline-none"
                        >
                          <option value="date-desc">New Stays</option>
                          <option value="date-asc">Old Stays</option>
                          <option value="amount-desc">High Treasury</option>
                          <option value="name-asc">Name A-Z</option>
                        </select>
                      </div>

                    </div>

                    {/* Guest Ledger Table */}
                    <div className="overflow-x-auto rounded border border-zinc-850 bg-zinc-900 shadow-xl">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="border-b border-zinc-850 font-mono text-[9px] text-zinc-500 uppercase tracking-wider bg-zinc-950/35">
                            <th className="py-3.5 px-4 font-semibold">Voucher ID</th>
                            <th className="py-3.5 px-4 font-semibold">Guest & Contact</th>
                            <th className="py-3.5 px-4 font-semibold">Cabin Sanctuary</th>
                            <th className="py-3.5 px-4 font-semibold">Stay Dates</th>
                            <th className="py-3.5 px-4 font-semibold">Total Amount</th>
                            <th className="py-3.5 px-4 font-semibold text-center">Status (Cycle)</th>
                            <th className="py-3.5 px-4 font-semibold text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-zinc-950 font-sans text-xs">
                          {sortedBookings.length > 0 ? (
                            sortedBookings.map((book) => {
                              const isActionLoading = actionLoadingId === book.id;
                              return (
                                <tr key={book.id} className="hover:bg-zinc-850/40 transition-colors">
                                  {/* Voucher ID */}
                                  <td className="py-4 px-4 font-mono text-[10px] text-zinc-500">
                                    #{book.id.replace('booking-', '')}
                                  </td>

                                  {/* Guest details */}
                                  <td className="py-4 px-4">
                                    <div className="font-semibold text-zinc-200">{book.guestName}</div>
                                    <div className="text-[10px] text-zinc-500 font-mono">{book.guestEmail}</div>
                                  </td>

                                  {/* Cabin assigned */}
                                  <td className="py-4 px-4 font-serif text-zinc-300">
                                    {book.roomTitle}
                                  </td>

                                  {/* Dates timeline */}
                                  <td className="py-4 px-4 font-mono text-[10px] text-zinc-400">
                                    <div>{book.checkIn}</div>
                                    <div className="text-[9px] text-zinc-600">to {book.checkOut}</div>
                                  </td>

                                  {/* Amount in Rupees */}
                                  <td className="py-4 px-4 font-semibold text-amber-400 font-serif text-sm">
                                    ₹{book.amount.toLocaleString('en-IN')}
                                  </td>

                                  {/* Status Cycling Pill */}
                                  <td className="py-4 px-4 text-center">
                                    <button
                                      onClick={() => handleCycleStatus(book)}
                                      disabled={isActionLoading}
                                      title="Cycle Status: Confirmed -> Pending -> Checked In -> Cancelled"
                                      className={`px-2.5 py-1 rounded text-[9px] font-mono font-semibold uppercase tracking-wider inline-flex items-center gap-1.5 cursor-pointer transition-all ${
                                        book.status === 'confirmed' && 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 hover:bg-emerald-500/20'
                                      } ${
                                        book.status === 'pending' && 'bg-amber-500/10 border border-amber-500/20 text-amber-500 hover:bg-amber-500/20'
                                      } ${
                                        book.status === 'checked-in' && 'bg-blue-500/10 border border-blue-500/20 text-blue-500 hover:bg-blue-500/20'
                                      } ${
                                        book.status === 'cancelled' && 'bg-red-500/10 border border-red-500/20 text-red-400 hover:bg-red-500/20'
                                      }`}
                                    >
                                      <span className={`w-1.5 h-1.5 rounded-full ${
                                        book.status === 'confirmed' ? 'bg-emerald-500' :
                                        book.status === 'pending' ? 'bg-amber-500' : 
                                        book.status === 'checked-in' ? 'bg-blue-500' : 'bg-red-500'
                                      }`} />
                                      <span>{book.status}</span>
                                    </button>
                                  </td>

                                  {/* Operations */}
                                  <td className="py-4 px-4 text-right">
                                    <div className="flex items-center justify-end gap-1">
                                      <button
                                        onClick={() => startEditing(book)}
                                        className="p-1.5 text-zinc-500 hover:text-amber-500 rounded hover:bg-zinc-950 transition-colors cursor-pointer"
                                        title="Edit stay details"
                                      >
                                        <Edit3 className="w-3.5 h-3.5" />
                                      </button>
                                      <button
                                        onClick={() => handleDeleteBooking(book.id)}
                                        disabled={isActionLoading}
                                        className="p-1.5 text-zinc-600 hover:text-red-400 rounded hover:bg-red-950/20 transition-colors cursor-pointer"
                                        title="Cancel / Delete reservation"
                                      >
                                        {isActionLoading ? (
                                          <RefreshCw className="w-3.5 h-3.5 animate-spin text-zinc-600" />
                                        ) : (
                                          <Trash2 className="w-3.5 h-3.5" />
                                        )}
                                      </button>
                                    </div>
                                  </td>
                                </tr>
                              );
                            })
                          ) : (
                            <tr>
                              <td colSpan={7} className="py-12 text-center text-zinc-600 italic">
                                No guest registrations found matching specified criteria.
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* TAB 4: MANUAL BOOKING FORM */}
                {activeTab === 'create-booking' && (
                  <div className="bg-zinc-900 p-6 rounded border border-zinc-850 max-w-2xl mx-auto space-y-6">
                    <div className="space-y-1">
                      <h3 className="font-serif text-xl font-bold text-zinc-100">Direct Offline Check-in Setup</h3>
                      <p className="text-xs text-zinc-500 font-light">Register direct guests, agent stays, or off-grid travelers directly into the sanctuary ledger system.</p>
                    </div>

                    <form onSubmit={handleManualBookingSubmit} className="space-y-4 text-sm">
                      <div className="space-y-1.5">
                        <label className="font-mono text-[8px] text-zinc-500 uppercase tracking-widest block">Assign Cabin Sanctuary</label>
                        <select
                          value={newRoomId}
                          onChange={(e) => setNewRoomId(e.target.value)}
                          className="w-full bg-zinc-950 border border-zinc-850 px-3.5 py-2.5 rounded text-zinc-300 focus:border-amber-500/50 cursor-pointer focus:outline-none"
                        >
                          <option value="hearth-suite">The Hearth Suite (₹24,500/night)</option>
                          <option value="valley-view-cabin">The Valley View Cabin (₹28,000/night)</option>
                        </select>
                      </div>

                      <div className="grid sm:grid-cols-2 gap-4">
                        <div className="space-y-1.5">
                          <label className="font-mono text-[8px] text-zinc-500 uppercase tracking-widest block">Guest Full Name</label>
                          <input
                            type="text"
                            value={newName}
                            onChange={(e) => setNewName(e.target.value)}
                            placeholder="e.g. Vikram Sen"
                            className="w-full bg-zinc-950 border border-zinc-850 px-3.5 py-2.5 rounded text-zinc-350 focus:border-amber-500/50 focus:outline-none font-light"
                            required
                          />
                        </div>
                        <div className="space-y-1.5">
                          <label className="font-mono text-[8px] text-zinc-500 uppercase tracking-widest block">Email Address</label>
                          <input
                            type="email"
                            value={newEmail}
                            onChange={(e) => setNewEmail(e.target.value)}
                            placeholder="e.g. vikram@sens.co.in"
                            className="w-full bg-zinc-950 border border-zinc-850 px-3.5 py-2.5 rounded text-zinc-350 focus:border-amber-500/50 focus:outline-none font-light"
                            required
                          />
                        </div>
                      </div>

                      <div className="grid sm:grid-cols-2 gap-4">
                        <div className="space-y-1.5">
                          <label className="font-mono text-[8px] text-zinc-500 uppercase tracking-widest block">Check-in Date</label>
                          <input
                            type="date"
                            value={newCheckIn}
                            onChange={(e) => setNewCheckIn(e.target.value)}
                            className="w-full bg-zinc-950 border border-zinc-850 px-3.5 py-2.5 rounded text-zinc-350 focus:border-amber-500/50 focus:outline-none font-mono"
                            required
                          />
                        </div>
                        <div className="space-y-1.5">
                          <label className="font-mono text-[8px] text-zinc-500 uppercase tracking-widest block">Check-out Date</label>
                          <input
                            type="date"
                            value={newCheckOut}
                            onChange={(e) => setNewCheckOut(e.target.value)}
                            className="w-full bg-zinc-950 border border-zinc-850 px-3.5 py-2.5 rounded text-zinc-350 focus:border-amber-500/50 focus:outline-none font-mono"
                            required
                          />
                        </div>
                      </div>

                      <div className="space-y-1.5">
                        <label className="font-mono text-[8px] text-zinc-500 uppercase tracking-widest block">Custom Stays Total Amount (INR) — Leave Blank to Auto-Calculate</label>
                        <input
                          type="number"
                          value={newAmount}
                          onChange={(e) => setNewAmount(e.target.value)}
                          placeholder="Calculates automatically based on room nightly rates if blank"
                          className="w-full bg-zinc-950 border border-zinc-850 px-3.5 py-2.5 rounded text-zinc-350 focus:border-amber-500/50 focus:outline-none font-light font-mono"
                        />
                      </div>

                      <button
                        type="submit"
                        disabled={actionLoadingId === 'manual-submit'}
                        className="w-full py-3 bg-amber-600 hover:bg-amber-500 disabled:bg-zinc-850 text-zinc-950 font-bold uppercase tracking-wider text-xs rounded transition-colors cursor-pointer flex items-center justify-center gap-2 mt-4 shadow-lg shadow-black/20"
                      >
                        {actionLoadingId === 'manual-submit' ? 'Logging reservation...' : 'Commit Stay to Ledger'}
                      </button>
                    </form>
                  </div>
                )}

              </main>

              {/* Status footer with counter */}
              <footer className="px-6 md:px-8 py-3.5 border-t border-zinc-850 bg-zinc-900 flex justify-between items-center text-[10px] font-mono text-zinc-500 shrink-0">
                <span>Registrar system offline backup active</span>
                <span>Active records mapped: {filteredBookings.length} stay files</span>
              </footer>

            </div>

            {/* INLINE EDIT DIALOG MODAL / DRAWER */}
            <AnimatePresence>
              {editingBooking && (
                <div className="fixed inset-0 z-55 flex items-center justify-center p-4">
                  {/* Local Backdrop overlay */}
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    onClick={() => setEditingBooking(null)}
                    className="fixed inset-0 bg-zinc-950/80 backdrop-blur-sm"
                  />

                  {/* Edit Panel container */}
                  <motion.div
                    initial={{ opacity: 0, scale: 0.97 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.97 }}
                    className="relative bg-zinc-900 border border-zinc-800/80 rounded shadow-2xl p-6 md:p-8 w-full max-w-md z-10 space-y-5"
                  >
                    <button
                      onClick={() => setEditingBooking(null)}
                      className="absolute top-4 right-4 p-1.5 text-zinc-500 hover:text-white rounded hover:bg-zinc-800/40 cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>

                    <div className="space-y-1">
                      <span className="font-mono text-[8px] text-amber-500 uppercase tracking-widest">RECORD MODIFICATION</span>
                      <h4 className="font-serif text-lg font-bold text-zinc-100">
                        Edit Stay Parameters
                      </h4>
                      <p className="text-[11px] text-zinc-500 leading-none">Modify values for Ticket ID #{editingBooking.id.replace('booking-', '')}</p>
                    </div>

                    <form onSubmit={handleSaveEdit} className="space-y-3.5 text-xs font-sans">
                      {/* Name */}
                      <div className="space-y-1">
                        <label className="font-mono text-[8px] text-zinc-500 uppercase tracking-widest">Guest Name</label>
                        <input
                          type="text"
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          className="w-full bg-zinc-950 border border-zinc-850 px-3 py-2 rounded text-zinc-350 focus:border-amber-500/50 focus:outline-none"
                          required
                        />
                      </div>

                      {/* Email */}
                      <div className="space-y-1">
                        <label className="font-mono text-[8px] text-zinc-500 uppercase tracking-widest">Guest Email</label>
                        <input
                          type="email"
                          value={editEmail}
                          onChange={(e) => setEditEmail(e.target.value)}
                          className="w-full bg-zinc-950 border border-zinc-850 px-3 py-2 rounded text-zinc-350 focus:border-amber-500/50 focus:outline-none"
                          required
                        />
                      </div>

                      {/* Dates */}
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <label className="font-mono text-[8px] text-zinc-500 uppercase tracking-widest">Arrival</label>
                          <input
                            type="date"
                            value={editCheckIn}
                            onChange={(e) => setEditCheckIn(e.target.value)}
                            className="w-full bg-zinc-950 border border-zinc-850 px-3 py-2 rounded text-zinc-350 focus:border-amber-500/50 focus:outline-none font-mono"
                            required
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="font-mono text-[8px] text-zinc-500 uppercase tracking-widest">Departure</label>
                          <input
                            type="date"
                            value={editCheckOut}
                            onChange={(e) => setEditCheckOut(e.target.value)}
                            className="w-full bg-zinc-950 border border-zinc-850 px-3 py-2 rounded text-zinc-350 focus:border-amber-500/50 focus:outline-none font-mono"
                            required
                          />
                        </div>
                      </div>

                      {/* Amount */}
                      <div className="space-y-1">
                        <label className="font-mono text-[8px] text-zinc-500 uppercase tracking-widest">Stay Amount (₹ INR)</label>
                        <input
                          type="number"
                          value={editAmount}
                          onChange={(e) => setEditAmount(parseFloat(e.target.value) || 0)}
                          className="w-full bg-zinc-950 border border-zinc-850 px-3 py-2 rounded text-zinc-350 focus:border-amber-500/50 focus:outline-none font-mono"
                          required
                        />
                      </div>

                      {/* Status */}
                      <div className="space-y-1">
                        <label className="font-mono text-[8px] text-zinc-500 uppercase tracking-widest">Cabin State Status</label>
                        <select
                          value={editStatus}
                          onChange={(e: any) => setEditStatus(e.target.value)}
                          className="w-full bg-zinc-950 border border-zinc-850 px-3 py-2 rounded text-zinc-350 focus:border-amber-500/50 cursor-pointer focus:outline-none"
                        >
                          <option value="confirmed">Confirmed</option>
                          <option value="pending">Pending</option>
                          <option value="checked-in">Checked In</option>
                          <option value="cancelled">Cancelled</option>
                        </select>
                      </div>

                      <div className="pt-3.5 flex gap-2">
                        <button
                          type="button"
                          onClick={() => setEditingBooking(null)}
                          className="flex-grow py-2.5 bg-zinc-800 hover:bg-zinc-750 text-zinc-400 rounded text-xs uppercase tracking-widest font-mono cursor-pointer transition-colors"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          disabled={actionLoadingId === editingBooking.id}
                          className="flex-grow py-2.5 bg-amber-600 hover:bg-amber-500 text-zinc-950 font-bold rounded text-xs uppercase tracking-widest font-mono cursor-pointer transition-colors"
                        >
                          {actionLoadingId === editingBooking.id ? 'Saving...' : 'Save Record'}
                        </button>
                      </div>
                    </form>
                  </motion.div>
                </div>
              )}
            </AnimatePresence>

          </div>
        )}

        {/* LOGOUT CONFIRMATION MODAL */}
        <AnimatePresence>
          {showLogoutConfirm && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-zinc-900 border border-zinc-800 rounded p-6 max-w-sm w-full shadow-2xl relative"
              >
                <div className="flex justify-center mb-4">
                  <div className="w-12 h-12 bg-red-950/30 border border-red-900/50 rounded-full flex items-center justify-center">
                    <LogOut className="w-5 h-5 text-red-500" />
                  </div>
                </div>
                <h3 className="text-xl font-serif font-bold text-center text-zinc-100 mb-2">
                  Confirm Logout
                </h3>
                <p className="text-center text-zinc-400 text-xs font-light mb-6">
                  Are you sure you want to lock the staff portal? You will need your credentials to return.
                </p>
                <div className="flex gap-3">
                  <button
                    onClick={() => setShowLogoutConfirm(false)}
                    className="flex-1 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded text-xs uppercase tracking-widest font-mono cursor-pointer transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={confirmLogout}
                    className="flex-1 py-2.5 bg-red-900/80 hover:bg-red-800 text-red-100 font-bold rounded text-xs uppercase tracking-widest font-mono cursor-pointer transition-colors"
                  >
                    Logout
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </AnimatePresence>
  );
}
