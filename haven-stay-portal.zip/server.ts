import express from "express";
import path from "path";
import fs from "fs";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import nodemailer from "nodemailer";
import { ROOMS, EXPERIENCES } from "./src/data/havenData";
import { Booking } from "./src/types";

// Load environment variables
dotenv.config();

const app = express();
const PORT = 3000;

// Enable JSON parse middleware
app.use(express.json());

// Initialize Nodemailer Transporter for Gmail
let transporter: nodemailer.Transporter | null = null;
if (process.env.GMAIL_USER && process.env.GMAIL_APP_PASSWORD && process.env.GMAIL_USER !== "your_email@gmail.com") {
  transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.GMAIL_USER,
      pass: process.env.GMAIL_APP_PASSWORD,
    },
  });
  console.log("Gmail SMTP transporter initialized.");
} else {
  console.warn("GMAIL_USER or GMAIL_APP_PASSWORD is missing or invalid. Emails will only be simulated.");
}

// Initialize Gemini Client safely
let ai: GoogleGenAI | null = null;
try {
  const apiKey = process.env.GEMINI_API_KEY;
  if (apiKey && apiKey !== "MY_GEMINI_API_KEY") {
    ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
    console.log("Gemini API Client initialized successfully.");
  } else {
    console.warn("GEMINI_API_KEY is not configured or has placeholder value. Running chat in echo/simulated mode.");
  }
} catch (err) {
  console.error("Failed to initialize Gemini client:", err);
}

// In-Memory Bookings Database
const bookings: Booking[] = [
  {
    id: "booking-101",
    roomId: "hearth-suite",
    roomTitle: "The Hearth Suite",
    guestName: "Evelyn Sterling",
    guestEmail: "evelyn@example.com",
    checkIn: "2026-07-10",
    checkOut: "2026-07-15",
    amount: 122500,
    status: "confirmed",
    bookedAt: new Date(Date.now() - 3600000 * 24).toISOString()
  }
];

// API ROUTE: Get Rooms
app.get("/api/properties", (req, res) => {
  res.json({ success: true, count: ROOMS.length, data: ROOMS });
});

// API ROUTE: Get Experiences
app.get("/api/experiences", (req, res) => {
  res.json({ success: true, count: EXPERIENCES.length, data: EXPERIENCES });
});

// API ROUTE: Get Active Bookings
app.get("/api/bookings", (req, res) => {
  res.json({ success: true, count: bookings.length, data: bookings });
});

// API ROUTE: Create New Booking
app.post("/api/bookings", (req, res) => {
  const { roomId, guestName, guestEmail, checkIn, checkOut, amount } = req.body;

  if (!roomId || !guestName || !guestEmail || !checkIn || !checkOut) {
    return res.status(400).json({ success: false, error: "Missing required booking details." });
  }

  const selectedRoom = ROOMS.find(r => r.id === roomId);
  if (!selectedRoom) {
    return res.status(404).json({ success: false, error: "Selected room sanctuary not found." });
  }

  const bookingId = `booking-${Math.floor(10000 + Math.random() * 90000)}`;
  const newBooking: Booking = {
    id: bookingId,
    roomId,
    roomTitle: selectedRoom.title,
    guestName,
    guestEmail,
    checkIn,
    checkOut,
    amount: amount || selectedRoom.pricePerNight * 2, // fallback to typical 2-night min
    status: "confirmed",
    bookedAt: new Date().toISOString()
  };

  bookings.push(newBooking);
  console.log(`New sanctuary booking registered: ${bookingId}`, newBooking);

  // Email Notification System using Nodemailer
  const totalDue = (amount || selectedRoom.pricePerNight * 2).toLocaleString('en-IN');
  
  if (transporter) {
    try {
      // Send confirmation to guest
      transporter.sendMail({
        from: `"Haven Retreat" <${process.env.GMAIL_USER}>`,
        to: guestEmail,
        subject: 'Sanctuary Confirmed - Haven Retreat',
        html: `
          <div style="font-family: sans-serif; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
            <h2 style="color: #b45309; font-family: serif;">Your sanctuary stay is secured.</h2>
            <p>Dear ${guestName},</p>
            <p>We are delighted to confirm your reservation for <strong>${selectedRoom.title}</strong>.</p>
            <div style="background-color: #f9f9f9; border-left: 4px solid #b45309; padding: 15px; margin: 20px 0;">
              <p style="margin: 0 0 10px 0;"><strong>Dates:</strong> ${checkIn} to ${checkOut}</p>
              <p style="margin: 0;"><strong>Total Due at Arrival:</strong> ₹${totalDue}</p>
            </div>
            <p>We look forward to welcoming you to the valley.</p>
            <p>Warm regards,<br>The Haven Retreat Team</p>
          </div>
        `
      }).catch(err => console.error("Failed to send guest email:", err));

      // Send alert to admin
      transporter.sendMail({
        from: `"Haven System" <${process.env.GMAIL_USER}>`,
        to: process.env.GMAIL_USER, // Send alert to the same admin email
        subject: `NEW RESERVATION ALERT - ${bookingId}`,
        html: `
          <div style="font-family: monospace; padding: 20px;">
            <h3>New Stay Logged</h3>
            <p><strong>Guest:</strong> ${guestName} (${guestEmail})</p>
            <p><strong>Room:</strong> ${selectedRoom.title}</p>
            <p><strong>Dates:</strong> ${checkIn} to ${checkOut}</p>
            <p><strong>Amount:</strong> ₹${totalDue}</p>
          </div>
        `
      }).catch(err => console.error("Failed to send admin email:", err));
      
      console.log(`Email dispatch initiated via Gmail SMTP for booking ${bookingId}`);
    } catch (error) {
      console.error('Failed to dispatch emails via Gmail:', error);
    }
  } else {
    // MOCK EMAIL NOTIFICATION SYSTEM (Fallback)
    console.log(`\n=== 📧 EMAIL DISPATCH SYSTEM (SIMULATED) ===`);
    console.log(`[TO: ${guestEmail}]`);
    console.log(`Subject: Sanctuary Confirmed - Haven Retreat`);
    console.log(`Body: Dear ${guestName},\n\nYour sanctuary stay in ${selectedRoom.title} is secured.\nDates: ${checkIn} to ${checkOut}\nTotal Due at Arrival: ₹${totalDue}\n\nWe look forward to welcoming you to the valley.\n`);
    
    console.log(`[TO: admin@havenretreat.com]`);
    console.log(`Subject: NEW RESERVATION ALERT - ${bookingId}`);
    console.log(`Body: New stay logged by ${guestName} (${guestEmail}).\nRoom: ${selectedRoom.title}\nDates: ${checkIn} to ${checkOut}\nAmount: ₹${totalDue}`);
    console.log(`================================\n`);
  }

  res.status(201).json({ success: true, data: newBooking });
});

// API ROUTE: Staff/Admin Login
app.post("/api/admin/login", (req, res) => {
  const { username, password } = req.body;
  if (username === "admin" && password === "haven2026") {
    res.json({ success: true, message: "Welcome back, Keeper of the Hearth." });
  } else {
    res.status(401).json({ success: false, error: "Invalid staff credentials. The valley winds reject your pass." });
  }
});

// API ROUTE: Update Booking Status
app.patch("/api/bookings/:id", (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  const booking = bookings.find(b => b.id === id);
  
  if (!booking) {
    return res.status(404).json({ success: false, error: "Sanctuary booking not found." });
  }

  if (status) {
    booking.status = status;
  }

  res.json({ success: true, data: booking });
});

// API ROUTE: Delete/Cancel Booking
app.delete("/api/bookings/:id", (req, res) => {
  const { id } = req.params;
  const index = bookings.findIndex(b => b.id === id);

  if (index === -1) {
    return res.status(404).json({ success: false, error: "Sanctuary booking not found." });
  }

  const removed = bookings.splice(index, 1);
  console.log(`Sanctuary booking deleted: ${id}`, removed[0]);
  res.json({ success: true, message: "Booking removed successfully." });
});

// API ROUTE: Chat with Hosts at the Hearth (Gemini Model)
app.post("/api/chat", async (req, res) => {
  const { messages } = req.body;

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ success: false, error: "Messages array is required." });
  }

  const systemInstruction = 
    `You are Sajad, the warm, hospitable, and slow-living host of Haven Retreat in Kashmir. ` +
    `Your speech is soothing, wise, deeply respectful, and poetic. You treat every guest as a long-lost family member. ` +
    `Encourage guests to leave their fast schedules behind and sit by our stone-built cedar wood hearth. ` +
    `Inform guests about our rooms: ` +
    `1. The Hearth Suite (Velvet Shadows & Open Flames, features hand-carved Khatamband ceilings and a grand stone fireplace, ₹24,500/night)\n` +
    `2. The Valley View Cabin (Where the Horizon Meets the Hearth, features panoramic windows, private heated wooden deck, ₹28,000/night).\n` +
    `Explain our experiences: Twilight on the Lake (wooden Shikara sunset ride on Dal Lake), The Morning Kahwa Circle (brewed saffron copper samovar tea), and the Artisan Path (weaving and woodcraft old-town masterclass).\n` +
    `Speak with a peaceful, warm, letter-like tone. Suggest hot saffron Kahwa tea or wearing a warm wool Pheran cloak. ` +
    `If you can help with booking dates, encourage them to lock in their sanctuary using our Check Availability panel at any time. ` +
    `Answer with a friendly, personal Kashmiri perspective. Keep replies descriptive but intimate and atmospheric.`;

  // Format history for Gemini SDK
  // Since we are using standard Gemini SDK, format messages array:
  // Each history object: content with parts: { text: ... } and role: user/model
  const formattedContents = messages.map((msg: any) => ({
    role: msg.role === "user" ? "user" : "model",
    parts: [{ text: msg.text }]
  }));

  try {
    if (ai) {
      // Use standard SDK generateContent with model gemini-3.5-flash
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: formattedContents,
        config: {
          systemInstruction: systemInstruction,
          temperature: 0.85,
        }
      });

      const replyText = response.text || "I am sitting by the cedar fire, pouring tea. Let me know when you are ready to come home.";
      return res.json({ success: true, text: replyText });
    } else {
      // Elegant simulated fallback response if Gemini Key is not configured yet
      const lastMessage = messages[messages.length - 1]?.text?.toLowerCase() || "";
      let simulatedReply = "";

      if (lastMessage.includes("room") || lastMessage.includes("suite") || lastMessage.includes("cabin") || lastMessage.includes("stay")) {
        simulatedReply = "Ah, you are asking about our rooms, my friend. The Hearth Suite is bathed in velvet shadows and features a beautiful stone fireplace where we keep cedar logs burning late. The Valley View Cabin has vast windows so you can look at the snowy peak from a warm blanket. Tell me, which of these feels like your sanctuary?";
      } else if (lastMessage.includes("experience") || lastMessage.includes("shikara") || lastMessage.includes("kahwa")) {
        simulatedReply = "We would love to share Srinagar through our eyes. We will drift on Dal Lake in a wooden Shikara as the sky turns neon rose and indigo, and share freshly brewed saffron Kahwa. It is the perfect cure for a noisy mind. Have you ever tasted traditional saffron tea?";
      } else {
        simulatedReply = "As-salamu alaykum, my dear friend. Welcome to Haven. I have just stoked the hearth fire, and Farida is brewing a fresh copper samovar of spice-infused Kahwa. Sit with us, wrap a wool blanket, and tell us: what brings you to our quiet mountains?";
      }

      // Add a slight sleep to simulate real AI thinking latency
      await new Promise(resolve => setTimeout(resolve, 800));
      return res.json({ success: true, text: simulatedReply, simulated: true });
    }
  } catch (err: any) {
    console.error("Gemini API Error:", err);
    res.status(500).json({ success: false, error: err.message || "Something went wrong stoking the hearth fire." });
  }
});

// Configure Vite middleware or production serving
async function setupServer() {
  if (process.env.NODE_ENV !== "production") {
    // Development Mode
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Mounted Vite development middleware.");
  } else {
    // Production Mode
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
    console.log("Serving static production assets from /dist.");
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Haven Stay Portal Router] Server running live on http://localhost:${PORT}`);
  });
}

setupServer();
